<?php

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Welcome to Second Gear, find used auto parts, used engines, transmissions, steering, and much more.</title>
  <meta content="" name="We are the fastest channel in finding your auto part in the used market place.">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <div id="serverMsg" class="col-12 col-md-5 myAlert fade myHide" tabindex="-1">
    <div class="msgHeader d-flex">
      <h5 id="msgTitle" class="col-11">Title</h5>
      <button type="button" class="btn-close col-1" data-bs-dismiss="myAlert" aria-label="Close"></button>
    </div>
    <hr>
    <div class="msgBody">
      <p id="textResponse"></p>
    </div>
    <hr>
    <div class="msgFooter">
      <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="myAlert" aria-label="Close">OK</button>
    </div>
  </div>


  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-center">

      <!-- <h1 class="logo"><a href="index.html">Second Gear</a></h1> -->
      <!-- Uncomment below if you prefer to use an image logo -->
      <a href="" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about-boxes">About</a></li>
          <li><a class="nav-link scrollto" href="#blog">Blog</a></li>
          <li><a class="nav-link scrollto " href="#ready">Ready to Deliver</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          <li><a class="getstarted scrollto" href="#hero">Get Started</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <!-- <div class="hero-container d-flex flex-row ms-auto" data-aos="fade-up" data-aos-delay="150"> -->
    <div class="hero-container d-flex row flex-lg-row" data-aos="fade-up" data-aos-delay="150">
      <div class="col col-lg-6 row align-items-center">
        <div class="my-quary-form">
          <h1>Unlock Value, Drive, Quality</h1>
          <h2>Your source for Premium Second-Hand Auto Parts</h2>
          <!-- <div class="d-flex">
            <a href="#about" class="btn-get-started scrollto">Get Started</a>
            <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="glightbox btn-watch-video"><i class="bi bi-play-circle"></i><span>Watch Video</span></a>
          </div> -->
        </div>
      </div>
      <div class="col col-lg-6 row align-items-center">
        <div class="my-quary-form col-md-10 col-lg-8 col-xxl-6">
          <h2>Find a part now!</h2>
          <hr>
          <div id="quary-form" xroll="form">

            <select onchange="getMake(this.value)" class="form-select form-select-lg" id="fsyear" aria-label="YEAR">
              <option selected>YEAR</option>

              <?php
              $data = file_get_contents("./assets/json/the-list.json");
              $data = json_decode($data, true);
              $thisYear = "";

              foreach ($data as $row) {
                if ($thisYear != $row["Year"]) {
                  $thisYear = $row["Year"];
                  echo '<option>' . $row["Year"] . '</option>';
                }
              }
              ?>

            </select>

            <select onchange="getModel(this.value)" class="form-select form-select-lg" id="fsmake" aria-label="MAKE" disabled>
              <option selected>MAKE</option>
              <!-- <option>Select Year before selecting Make</option> -->
            </select>

            <select onchange="getPart(this.value)" class="form-select form-select-lg" id="fsmodel" aria-label="MODEL" disabled>
              <option selected>MODEL</option>
              <!-- <option>Select Make before selecting Model</option> -->
            </select>

            <select onchange="setSubmit()" class="form-select form-select-lg" id="fspart" aria-label="PART" disabled>
              <option selected>PART</option>
              <?php
              $data = file_get_contents("./assets/json/the-parts.json");
              $data = json_decode($data, true);

              foreach ($data as $row) {
                echo '<option>' . $row["Part"] . '</option>';
              }
              ?>
            </select>

            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
              <!-- <button id="goFind" type="submit" class="btn btn-danger btn-lg" disabled>Go Find 'EM</button> -->
              <button type="button" id="goFind" data-bs-toggle="modal" data-bs-target="#ci-modal" class="btn btn-danger btn-lg" disabled>Go Find 'EM</button>
            </div>

          </div>

          <div id="ci-modal" class="modal fade" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">You are almost there</h5>
                  <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
                </div>
                <div class="modal-body">
                  <p>Please give us your contact info to send you our finding soon.</p>

                  <div id="errMsgForm" class="errMsgForm myHide">All flields are required to be filled</div>
                  <form id="info-form" class="needs-validation" novalidate>
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="ipname" autocomplete="name" required>
                      <label for="ipname" class="form-label">Name</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="email" class="form-control" id="ipemail" aria-describedby="emailHelp" autocomplete="email" required>
                      <label for="ipemail" class="form-label">Email</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="ipmobile" autocomplete="mobile" required>
                      <label for="ipmobile" class="form-label">Mobile</label>
                    </div>
                    <div class="form-floating mb-3">
                      <input type="text" class="form-control" id="ipzipcode" autocomplete="zipcode" required>
                      <label for="ipzipcode" class="form-label">Zip Code</label>
                    </div>

                    <div class="form-check mb-3">
                      <input class="form-check-input" type="checkbox" id="myCheck" value="" aria-describedby="invalidCheck3Feedback" required>
                      <label class="form-check-label" for="myCheck">I agree to the sites terms & conditions.</label>
                      <!-- <div class="valid-feedback">Valid.</div> -->
                    </div>

                    <hr>

                    <button type="button" id="btn-close" class="btn btn-gray close myHide" data-bs-dismiss="modal" aria-label="Close">Close</button>
                    <button type="submit" class="btn btn-primary confirm">Confirm Request</button>
                  </form>
                  <!-- End Form -->
                </div>
                <!-- End Body -->
              </div>
              <!-- End Content -->
            </div>

            <hr>
            <!-- <h2>Call us on +1</h2> -->
          </div>
        </div>
      </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= What we do Best Section ======= -->
    <section class="wwdb about">
      <div class="container" data-aos="fade-up">

        <div class="row justify-content-center">
          <div class="col-lg-11">
            <div class="row justify-content-center">

              <div class="col-12 d-md-flex align-items-md-stretch">
                <h3>Explore our curated selection of meticulously inspected second-hand auto parts, delivering reliability and affordability without any compromise.
                  Drive confidently with parts that redefine your vehicle's potential.</h3>
              </div>

            </div>
          </div>
        </div>

      </div>
    </section><!-- What we do best Section -->


    <!-- ======= About Section ======= -->
    <section id="perk" class="perk">
      <div class="container" data-aos="fade-up">

        <div class="row justify-content-center">
          <div class="col-lg-11">
            <div class="row justify-content-center">

              <div class="col-lg-4 col-md-4 col-12 d-md-flex align-items-md-stretch mb-sm-5 mb-5">
                <div class="count-box">
                  <i class="bi bi-truck"></i>
                  <span>Fast Shipping</span>
                  <p>Experience the convenience of lightning fast deliveries</p>
                </div>
              </div>

              <div class="col-lg-4 col-md-4 col-12 d-md-flex align-items-md-stretch mb-sm-5 mb-5">
                <div class="count-box">
                  <i class="bi bi-box"></i>
                  <span>Easy Returns</span>
                  <p>Product with any fault within 07 days for exchange</p>
                </div>
              </div>

              <div class="col-lg-4 col-md-4 col-12 d-md-flex align-items-md-stretch mb-sm-5 mb-5">
                <div class="count-box">
                  <i class="bi bi-clock"></i>
                  <span>Friendly Support</span>
                  <p>Our support team always ready to serve you 7 days a week</p>
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>
    </section>





    <!-- ======= About Section ======= -->
    <section id="blog" class="about">
      <div class="container" data-aos="fade-up">

        <!-- <div class="row justify-content-end">
          <div class="col-lg-11">
            <div class="row justify-content-end">

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="bi bi-emoji-smile"></i>
                  <span data-purecounter-start="0" data-purecounter-end="125" data-purecounter-duration="1" class="purecounter"></span>
                  <p>Happy Clients</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="bi bi-journal-richtext"></i>
                  <span data-purecounter-start="0" data-purecounter-end="185" data-purecounter-duration="1" class="purecounter"></span>
                  <p>Packages Delivered</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="bi bi-clock"></i>
                  <span data-purecounter-start="0" data-purecounter-end="5" data-purecounter-duration="1" class="purecounter"></span>
                  <p>Years of experience</p>
                </div>
              </div>

              <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
                <div class="count-box">
                  <i class="bi bi-award"></i>
                  <span data-purecounter-start="0" data-purecounter-end="158" data-purecounter-duration="1" class="purecounter"></span>
                  <p>Positive Feedbacks</p>
                </div>
              </div>

            </div>
          </div>
        </div>

        <hr> -->

        <div class="row">

          <div id="carouselExampleDark" class="carousel carousel-dark slide">

            <div class="carousel-indicators">
              <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
              <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
            </div>

            <div class="carousel-inner">
              <div class="carousel-item active align-items-center" data-bs-interval="10000">
                <div class="d-md-flex d-sm-block">
                  <div class="col-lg-5" data-aos="zoom-in" data-aos-delay="100">
                    <img src="assets/img/uncover-hidden-treasures.jpg" class="img-fluid" alt="">
                    <a href="./blog/uncover-hidden-treasures/" class="mb-4"></a>
                  </div>

                  <div class="col-lg-7 pt-3 pt-lg-0 blog content">
                    <h2>Uncover Hidden Treasures</h2>
                    <h4 class="fst-italic mx-1">Explore Our Second-Hand Ato Parts Articles</h4>
                    <h6 class="mx-1">Dive into a world of automotive knowledge and savings.
                      Our curated collection of articles and blogs unveils the secrets to finding top-notch second-hand auto parts. Empower your vehicle with wisdom.</h6>

                    <div class="d-grid blog-btn d-md-flex justify-content-md-end">
                      <button class="btn btn-outline-danger" type="button">Read More</button>
                    </div>
                    <!-- <button class="blog-btn">Read More</button> -->
                  </div>
                </div>
              </div>

              <div class="carousel-item" data-bs-interval="20000">
                <div class="d-md-flex d-sm-block">
                  <div class="col-lg-5" data-aos="zoom-in" data-aos-delay="100">
                    <img src="assets/img/welcome.jpg" class="img-fluid" alt="">
                    <a href="./blog/uncover-hidden-treasures/" class="mb-4"></a>
                  </div>

                  <div class="col-lg-7 pt-3 pt-lg-0 blog content">
                    <h2>Revitalize Your Ride with SecondGear Auto Parts</h2>
                    <h4 class="fst-italic mx-1">Welcome to SecondGear Auto Parts</h4>
                    <h6 class="mx-1">Where automotive enthusiasts find a treasure trove of quality second-hand auto components.
                      Our vast inventory ensures your vehicle receives the care it deserves, blending affordability with reliability for a smooth and efficient driving experience.</h6>

                    <div class="d-grid blog-btn d-md-flex justify-content-md-end">
                      <button class="btn btn-outline-danger" type="button">Read More</button>
                    </div>

                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
    </section><!-- End About Section -->

    <!-- ======= About Boxes Section ======= -->
    <section id="about-boxes" class="about-boxes aboutus">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <h2>About Us</h2>
          <h4 class="mx-sx-1">At SecondGear Auto Parts, we redefine reliability in the realm of second-hand auto components.</h4>
          <h6 class="mx-sx-1">Our commitment lies in delivering premium quality parts with unmatched service.
            Experience cost-effective solutions without compromising on excellence, making us your trusted partners in automotive restoration.</h6>
        </div>

      </div>
    </section><!-- End About Boxes Section -->


    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <p>Why choose secondgear autpoparts</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="200">
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-laptop"></i>
              <h4>Quality Assurance</h4>
              <p>Guaranteeing automotive parts exceed customer expectations for reliability and quality</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-bar-chart"></i>
              <h4>Exceptional Value</h4>
              <p>We understand the significance of striking a balance between affordability and excellence</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-brightness-high"></i>
              <h4>Wide Selection</h4>
              <p>Our diverse selection is designed to meet the unique needs of a wide spectrum of vehicles</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-briefcase"></i>
              <h4>Expert Guidance</h4>
              <p>We are dedicated to assisting you in making well-informed decisions, ensuring that you find the right parts for your automotive needs</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-card-checklist"></i>
              <h4>Customer Satisfaction</h4>
              <p>Your satisfaction is our paramount concern. We prioritize excellence in every interaction</p>
            </div>
          </div>
          <div class="col-md-6 mt-4 mt-md-0">
            <div class="icon-box">
              <i class="bi bi-clock"></i>
              <h4>Choose SecondGear Autoparts</h4>
              <p>We are committed to meeting and exceeding your expectations in the realm of second-hand auto components</p>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="zoom-in">

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <?php
            $data = file_get_contents("./assets/json/testimonials.json");
            $data = json_decode($data, true);

            foreach ($data as $row) {
              echo
              '<div class="swiper-slide">
                      <div class="testimonial-item">
                        <h3>' . $row["name"] . '</h3>
                        <h4>' . $row["place"] . '</h4>
                        <p>
                          <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                          ' . $row["statement"] . '
                          <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                        </p>
                      </div>
                    </div><!-- End testimonial item -->';
            }
            ?>

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="ready" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Delivery of</h2>
          <p>Ready to serve you</p>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/portfolio-1.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Engine</h4>
              <!-- <p>Model:</p> -->
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="assets/img/portfolio/portfolio-2.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Steering Wheel</h4>
              <!-- <p>Model:</p> -->
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/portfolio-3.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Alternator</h4>
              <!-- <p>Model:</p> -->
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="assets/img/portfolio/portfolio-4.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Turbocharger</h4>
              <!-- <p>Model:</p> -->
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="assets/img/portfolio/portfolio-5.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Radiator Assembly</h4>
              <!-- <p>Model:</p> -->
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/portfolio-6.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Differential Gears</h4>
              <!-- <p>Model:</p> -->
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="assets/img/portfolio/portfolio-7.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Suspension and Brake Assembly</h4>
              <!-- <p>Model</p> -->
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="assets/img/portfolio/portfolio-8.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Alloy Wheel</h4>
              <!-- <p>Model:</p> -->
            </div>
          </div>

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="assets/img/portfolio/portfolio-9.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Headlight</h4>
              <p>Model:</p>
            </div>
          </div> -->

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="assets/img/portfolio/portfolio-10.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Headlight</h4>
              <!-- <p>Model:</p> -->
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="assets/img/portfolio/portfolio-11.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Tail Light</h4>
              <!-- <p>Model:</p> -->
            </div>
          </div>

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="assets/img/portfolio/portfolio-12.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Tail Light</h4>
              <p>Model:</p>
            </div>
          </div> -->


        </div>

      </div>
    </section><!-- End Portfolio Section -->


    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class=" section-title">
          <h2>Contact</h2>
          <p>Contact Us</p>
        </div>

        <div class="row">

          <div class="col-lg-4" style="background-image: url(&quot;./assets/img/logo-contact.png&quot;);background-repeat: no-repeat;background-position: center;">

            <div class="row">
              <div class="col-12 mt-4">
                <div class="info-box mt-4">
                  <i class="bx bx-envelope"></i>
                  <h3>Email Us</h3>
                  <p>Info@secondgearautoparts.com<br>support@secondgearautoparts.com</p>
                </div>
              </div>
              <div class="col-12 mt-4">
                <div class="info-box mt-4">
                  <i class="bx bx-phone-call"></i>
                  <h3>Call Us</h3>
                  <p>+1 <br>+1 </p>
                </div>
              </div>
            </div>

          </div>

          <div class="col-lg-6 mt-4 mt-lg-0">
            <form action="forms/contact-form.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="Xerror-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 text-sm-center text-md-start">
            <div class="footer-info">
              <h3>SecondGear</h3>
              <p>
                9541 BALL ROAD<br>
                UNIT 302<br>
                ANAHEIM, CA 92804, USA<br><br>

                <!-- <strong>Phone:</strong> +1 <br> 
                <strong>Email:</strong> Sales@secondgearautoparts.com<br>  -->
              </p>
              <!-- <div class="social-links mt-3">
                <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
                <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
              </div> -->
            </div>
          </div>
          <div class="col-lg-9 col-md-6 footer-links d-flex justify-content-end align-items-center">
            <div class="single-line">
              <ul>
                <li><i class="bx bx-chevron-right"></i> <a href="terms-of-service.html">Terms of Service</a></li>
                <li><i class="bx bx-chevron-right"></i> <a href="shipping-return-policy.html">Shipping & Return Policy</a></li>
                <li><i class="bx bx-chevron-right"></i> <a href="refund-policy.html">Refund Policy</a></li>
                <li><i class="bx bx-chevron-right"></i> <a href="warranty.html">Warranty</a></li>
                <li><i class="bx bx-chevron-right"></i> <a href="privacy-policy.html">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>SecondGear Auto Parts</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Developed by <a href="https://vinodthadhani.com">Vinod Thadhani</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <!-- Developer JS Files -->
  <script src="assets/js/sitehudhaa.js"></script>


</body>

</html>