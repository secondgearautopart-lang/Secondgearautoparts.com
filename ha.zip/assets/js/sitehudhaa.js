/**
* Site Name: secondgearautoparts.com
* Updated: Dec 22 2023 with Bootstrap v5.3.2
* Template URL: https://bootstrapmade.com/dewi-free-multi-purpose-html-template/
* Template Author: BootstrapMade.com
* Site Developer: Vinod Thadhani
* Template License: https://bootstrapmade.com/license/
*/



    /** 
     * Populate dropboxes
     */
    async function getMake(syear) {
        let makeDropDown = document.querySelector("#fsmake");

        if (syear.trim() === "YEAR") {
            makeDropDown.disabled = true;
            makeDropDown.selectedIndex = 0;
            setSubmit();
            return false;
        }

        const response = await fetch('./assets/json/the-list.json');
        const data = await response.json();

        let out = "";
        out += '<option selected value="">MAKE</option>';
        let nMake = "";

        for (let index = 0; index < data.length; index++) {
            if (data[index]['Year'] === syear) {
                if (nMake != data[index]['Make']) {
                    nMake = data[index]['Make'];
                    out += '<option>' + data[index]['Make'] + '</option>';
                }
            }
        }

        makeDropDown.innerHTML = out;
        makeDropDown.disabled = false;
        setSubmit();

    }


    async function getModel(smake) {
        let syear = document.querySelector("#fsyear").value;
        let modelDropDown = document.querySelector("#fsmodel");

        if (syear.trim() === "YEAR") {
            modelDropDown.disabled = true;
            modelDropDown.selectedIndex = 0;
            setSubmit();
            return false;
        }

        if (smake.trim() === "MAKE") {
            modelDropDown.disabled = true;
            modelDropDown.selectedIndex = 0;
            setSubmit();
            return false;
        }

        const response = await fetch('./assets/json/the-list.json');
        const data = await response.json();

        let out = "";
        let nModel = "";
        out += '<option selected value="">MODEL</option>';

        for (let index = 0; index < data.length; index++) {
            if (data[index]['Year'] === syear && data[index]['Make'] === smake) {
                if (nModel != data[index]['Model']) {
                    nModel = data[index]['Model'];
                    out += '<option>' + data[index]['Model'] + '</option>';
                }
            }
        }

        modelDropDown.innerHTML = out;
        modelDropDown.disabled = false;
        setSubmit();
    }


    async function getPart(smodel) {
        let syear = document.querySelector("#fsyear").value;
        let smake = document.querySelector("#fsmake").value;
        let partDropDown = document.querySelector("#fspart");

        if (syear.trim() === "YEAR") {
            partDropDown.disabled = true;
            partDropDown.selectedIndex = 0;
            setSubmit();
            return false;
        }
        if (smake.trim() === "MAKE") {
            partDropDown.disabled = true;
            partDropDown.selectedIndex = 0;
            setSubmit();
            return false;
        }
        if (smodel.trim() === "MODEL") {
            partDropDown.disabled = true;
            partDropDown.selectedIndex = 0;
            setSubmit();
            return false;
        }
        partDropDown.disabled = false;
        setSubmit();
    }


    function setSubmit() {
        let syear = document.querySelector("#fsyear").value;
        let smake = document.querySelector("#fsmake").value;
        let smodel = document.querySelector("#fsmodel").value;
        let spart = document.querySelector("#fspart").value;
        let sbtn = document.querySelector("#goFind");

        if (syear.trim() === "YEAR" || syear.trim() === "") {
            sbtn.disabled = true;
            return false;
        }

        if (smake.trim() === "MAKE" || smake.trim() === "") {
            sbtn.disabled = true;
            return false;
        }

        if (smodel.trim() === "MODEL" || smodel.trim() === "") {
            sbtn.disabled = true;
            return false;
        }
        if (spart.trim() === "PART" || spart.trim() === "") {
            sbtn.disabled = true;
            return false;
        }

        sbtn.disabled = false;

    }





    /* 
     * Server Message 
     */
    var serMsgCon = document.getElementById('serverMsg');
    var clxBtn = serMsgCon.getElementsByTagName('button');
    if (clxBtn.length > 1) {

        clxBtn[0].addEventListener("click", function () {
            event.preventDefault();
            serMsgCon.classList.remove('show');
            serMsgCon.classList.add('myHide');
        });

        clxBtn[1].addEventListener("click", function () {
            event.preventDefault();
            serMsgCon.classList.remove('show');
            serMsgCon.classList.add('myHide');
        });
    }


    const sbtn = document.querySelector("#goFind");
    sbtn.addEventListener("click", function () {
        sbtn.disabled = true;
    });




    /*
     * Information Form
     */

    var fieldList;
    // Get the info form container element
    const i_f_c = document.getElementById("info-form");
    // Get the input fields and values
    const i_f_btn = i_f_c.getElementsByClassName("confirm");
    // Get button to close 
    const if_close_btn = document.getElementById("btn-close");


    if (i_f_btn.length < 2) {
        i_f_btn[0].addEventListener("click", function (event) {
            event.preventDefault();
            event.stopPropagation();

            if (i_f_c.checkValidity() != false) {
                // Collect Field Values
                fieldList = hitOnMe();

                // close modal
                if_close_btn.click();

                ajax("POST", "./forms/receive-data.php", true, fieldList, "processResponse");

            } else {
                // Notify user
                const if_errMsg = document.getElementById("errMsgForm");

                if_errMsg.classList.remove("myHide");
                setTimeout(function () {
                    if_errMsg.classList.add("myHide");
                }, 10000);

                console.log(i_f_c.validationMessage);
                false
            }
        });
    }


    function hitOnMe() {

        // Get the quary form container element
        var q_f_control = document.getElementById("quary-form");
        // Get the input fields and values
        var q_f_inputs = q_f_control.getElementsByTagName("select");

        var oldJsonObj = []; //this creates a new element into the object

        for (var i = 0; i < q_f_inputs.length; i++) {
            var x = {}
            x[q_f_inputs[i].id] = q_f_inputs[i].value;

            oldJsonObj.push(x); //adds the element x to array
        };

        // Get the info form container element
        var i_f_control = document.getElementById("info-form");
        // Get the input fields and values
        var i_f_inputs = i_f_control.getElementsByTagName("input");


        for (var i = 0; i < i_f_inputs.length; i++) {
            var x = {}
            x[i_f_inputs[i].id] = i_f_inputs[i].value;

            oldJsonObj.push(x); //adds the element x to array
        };

        return oldJsonObj;
    }

    function processResponse(e) {
        const serverResponseHolder = document.getElementById("textResponse");
        const serverResponseTitle = document.getElementById("msgTitle");
        serverResponseTitle.innerHTML = "We received your request";
        serverResponseHolder.innerHTML = e;

        const serMsgCon = document.getElementById("serverMsg");
        serMsgCon.classList.remove("myHide");
        serMsgCon.classList.add("show");

        // const forms = document.getElementsByClassName('needs-validation');
        // forms.classList.remove('was-validated');

    }

    function processError(errMsg) {
        const serverResponseHolder = document.getElementById("textResponse");
        const serverResponseTitle = document.getElementById("msgTitle");
        serverResponseTitle.innerHTML = errMsg;
        serverResponseHolder.innerHTML = "Some error occored, please try again.";

        const serMsgCon = document.getElementById("serverMsg");
        serMsgCon.classList.remove("myHide");
        serMsgCon.classList.add("show");

        // const forms = document.getElementsByClassName('needs-validation');
        // forms.classList.remove('was-validated');

        // SendEmailTodeveloper();
    }



    function ajax(axMethod, axFileName, axSync = true, sendData, respondTo, axTimeOutSec = 3000) {
        var ax = new XMLHttpRequest();

        ax.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                processResponse(this.responseText)
            } else {
                processError("System Error");
            }
        };
        ax.open(axMethod, axFileName, axSync);
        ax.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        ax.setRequestHeader("Content-Type", "application/json; charset=UTF-8")
        ax.send(JSON.stringify(sendData));

        setTimeout(function () {
            if (ax.readyState < 4) {
                // Timeout !
                ax.abort();
                processError("Time Out Error");
            }
        }, axTimeOutSec);

    }
    
