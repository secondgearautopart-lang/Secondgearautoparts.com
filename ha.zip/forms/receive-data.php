<?php

    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {

        // if (empty($_POST)) {
        //     echo "Post Empty";
        // } else {
        //     echo "Post Not Empty";
        // }
        
        $inputData = file_get_contents('php://input');
        
        $xobj = json_decode($inputData);
        $text = "";
            
        foreach ($xobj as $obj) {
            foreach ($obj as $key => $value) {
                $text = $text . "<span>" . substr($key, 2) . "</span>:  " . $value . "<br>";
            }
        }
        
        echo $text;
        $x = "";
        $x = sendEmailToWendor($text);
        if (!empty($x) ){
            echo $x;
        }
    } else {
        echo "************************************************* no post";
    }

    // var_dump($inputData);
    
    // echo $xobj[0].[0][1];


    function sendEmailToWendor($textBody){
        $errorMessage = "";
        $toEmail = 'admin@secondgearautoparts.com';
        $noReply = 'noReply@secondgearautoparts.com';
        $emailSubject = 'New Sales email from your inquiry form';
        $headers = ['From' => $toEmail, 'Reply-To' => $noReply, 'Content-type' => 'text/html; charset=utf-8'];
        $body = $textBody;
        // $body = join(PHP_EOL, $bodyParagraphs);

        if (mail($toEmail, $emailSubject, $body, $headers)) {

            // header('Location: thank-you.html');

        } else {
            $errorMessage = 'Oops, something went wrong with email. Please try again.';
        }

        return $errorMessage;

    }

?>